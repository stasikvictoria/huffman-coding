var searchData=
[
  ['balance_3',['balance',['../_dictionary_8h.html#a366995869b49fa777a4d6e54a0b60633',1,'Dictionary.c']]],
  ['bf_4',['bf',['../_dictionary_8h.html#a61bcba2a6bfdffdf01663ce15cd7abfa',1,'Dictionary.c']]],
  ['binary_5ftranslation_5',['binary_translation',['../_input_file_8h.html#a101725ac6db88063a72e50c3cc1f36df',1,'InputFile.c']]]
];
