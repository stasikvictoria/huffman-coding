var searchData=
[
  ['huffmandictionary_2eh_37',['HuffmanDictionary.h',['../_huffman_dictionary_8h.html',1,'']]],
  ['huffmancoding_38',['HuffmanCoding',['../md__r_e_a_d_m_e.html',1,'']]]
];
