var searchData=
[
  ['queue_58',['Queue',['../struct_queue.html',1,'Queue'],['../_data_types_8h.html#ace5f77e1b4b9f2da517bfc7f2a098fbe',1,'Queue():&#160;DataTypes.h']]],
  ['quick_5fsorting_59',['quick_sorting',['../_create_huffman_tree_8h.html#a51bf2af7ba653ab2713016b7b556a86b',1,'CreateHuffmanTree.c']]]
];
