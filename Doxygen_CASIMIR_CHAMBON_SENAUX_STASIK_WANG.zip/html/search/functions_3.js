var searchData=
[
  ['depth_96',['depth',['../_dictionary_8h.html#a6e9d6b864fece8dc6877fedcdb06c28c',1,'Dictionary.c']]],
  ['dequeue_97',['dequeue',['../_data_types_8h.html#aba9aaacf01625e22a00a3b9bbd02980f',1,'DataTypes.c']]]
];
