var searchData=
[
  ['occ_5fmin_114',['occ_min',['../_huffman_dictionary_8h.html#a0189e62da4ca97e956bebbba07479f7a',1,'HuffmanDictionary.c']]],
  ['open_5ffile_115',['open_file',['../_encoding_file_8h.html#a4e91379ce4dd630ef87fb32915bac64e',1,'EncodingFile.c']]]
];
